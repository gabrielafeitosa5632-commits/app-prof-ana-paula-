# RecombiLab 3D Android

App Android simples do RecombiLab 3D usando WebView.

## Como rodar

1. No VS Code, rode o backend:

```powershell
cd "C:\Users\Gabriela\Desktop\bioquimica\files\recombilab-backend"
venv\Scripts\Activate.ps1
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

2. Abra esta pasta no Android Studio:

```text
C:\Users\Gabriela\Desktop\bioquimica\recombilab-android
```

3. Aguarde o Gradle sincronizar.

4. Clique em Run.

No emulador Android, o app abre:

```text
http://10.0.2.2:8000/app/
```

`10.0.2.2` e o endereco especial que o emulador usa para acessar o servidor rodando no computador.

## Arquivos principais

- `app/src/main/java/br/com/recombilab/app/MainActivity.java`
- `app/src/main/res/drawable/recombilab_logo.png`
- `app/src/main/AndroidManifest.xml`

