package br.com.recombilab.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.http.SslError;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String[] APP_URLS = {
            "http://10.0.0.105:8000/app/",
            "http://10.0.2.2:8000/app/",
            "http://127.0.0.1:8000/app/"
    };

    private WebView webView;
    private ProgressBar progressBar;
    private LinearLayout loadingView;
    private LinearLayout errorView;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int urlIndex = 0;
    private boolean pageLoaded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor("#020817"));
        getWindow().setNavigationBarColor(Color.parseColor("#020817"));
        buildScreen();
        configureWebView();
        loadCurrentUrl();
    }

    private void buildScreen() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#020817"));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#020817"));
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setVisibility(View.GONE);
        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(4)
        );
        progressParams.gravity = Gravity.TOP;
        root.addView(progressBar, progressParams);

        loadingView = createMessageView("Carregando RecombiLab 3D", "Conectando ao servidor...");
        root.addView(loadingView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        errorView = createErrorView();
        errorView.setVisibility(View.GONE);
        root.addView(errorView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        setContentView(root);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                errorView.setVisibility(View.GONE);
                loadingView.setVisibility(View.VISIBLE);
                webView.setVisibility(View.INVISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageLoaded = true;
                loadingView.setVisibility(View.GONE);
                errorView.setVisibility(View.GONE);
                webView.setVisibility(View.VISIBLE);
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    tryNextUrlOrShowError();
                }
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
                tryNextUrlOrShowError();
            }
        });
    }

    private LinearLayout createMessageView(String titleText, String messageText) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(28), dp(28), dp(28), dp(28));
        box.setBackgroundColor(Color.parseColor("#020817"));

        ImageView logo = new ImageView(this);
        logo.setImageResource(getResources().getIdentifier("recombilab_logo", "drawable", getPackageName()));
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(168), dp(168));
        logoParams.bottomMargin = dp(18);
        box.addView(logo, logoParams);

        TextView title = new TextView(this);
        title.setText(titleText);
        title.setTextColor(Color.parseColor("#E6F4EE"));
        title.setTextSize(25);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        box.addView(title);

        TextView message = new TextView(this);
        message.setText(messageText);
        message.setTextColor(Color.parseColor("#94A3B8"));
        message.setTextSize(15);
        message.setGravity(Gravity.CENTER);
        message.setLineSpacing(0, 1.12f);
        LinearLayout.LayoutParams messageParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        messageParams.topMargin = dp(12);
        box.addView(message, messageParams);
        return box;
    }

    private LinearLayout createErrorView() {
        LinearLayout box = createMessageView(
                "Nao foi possivel abrir o app",
                "No VS Code, deixe o backend rodando com:\npython -m uvicorn app.main:app --host 0.0.0.0 --port 8000\n\nCelular fisico: http://10.0.0.105:8000/app/\nEmulador: http://10.0.2.2:8000/app/"
        );

        Button retry = new Button(this);
        retry.setText("Tentar novamente");
        retry.setTextColor(Color.parseColor("#04140A"));
        retry.setBackgroundColor(Color.parseColor("#9DFF57"));
        retry.setOnClickListener(v -> {
            urlIndex = 0;
            loadCurrentUrl();
        });
        LinearLayout.LayoutParams retryParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        retryParams.topMargin = dp(20);
        box.addView(retry, retryParams);

        return box;
    }

    private void tryNextUrlOrShowError() {
        if (pageLoaded) {
            return;
        }
        if (urlIndex < APP_URLS.length - 1) {
            urlIndex++;
            loadCurrentUrl();
        } else {
            showError();
        }
    }

    private void loadCurrentUrl() {
        pageLoaded = false;
        loadingView.setVisibility(View.VISIBLE);
        errorView.setVisibility(View.GONE);
        webView.setVisibility(View.INVISIBLE);
        webView.loadUrl(APP_URLS[urlIndex]);
        handler.postDelayed(() -> {
            if (!pageLoaded) {
                tryNextUrlOrShowError();
            }
        }, 6500);
    }

    private void showError() {
        webView.setVisibility(View.GONE);
        loadingView.setVisibility(View.GONE);
        errorView.setVisibility(View.VISIBLE);
        progressBar.setVisibility(View.GONE);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
